export default {
  name: 'badge'
};